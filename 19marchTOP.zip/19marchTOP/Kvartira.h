#pragma once
using namespace std;
#include <vector>

class Kvartira
{
public:
	vector<Room> rooms;

	void addRoom(Room room) {
		rooms.push_back(room);
	}
	//Kvartira(int kolvo);

};

