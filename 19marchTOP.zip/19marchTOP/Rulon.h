//#pragma once
//#include <iostream>
//using namespace std;
//class Rulon
//{
//public:
//	Rulon();
//	Rulon(string name, float len, float wid, double price);
//private:
//	string name;
//	float len;
//	float wid; 
//	double price;
//};

